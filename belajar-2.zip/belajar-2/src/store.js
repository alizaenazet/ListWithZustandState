import create from 'zustand';

const storeTeman = create((set)=>({
    people : [`Budi`, `Anton`],
    addPerson : (person) => 
        set((state) => ({people : [...state.people, person ]})),
    }))

const storeTodo = create((set)=>({
    todoList : [`mandi`, `futsal`],
    addTodo : (todo) => 
        set((state) => ({todoList : [...state.todoList, todo ]})),
    }))
export{storeTeman, storeTodo}