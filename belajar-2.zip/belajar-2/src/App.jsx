import People from "./components/People";
import PeopleAdd from "./components/PeopleAdd";

export default
function App() {
  
  return (
    <>
    <div>
    <p>State management</p>
    <People/>
    <PeopleAdd />
    </div>
    </>
  )
}


