import { storeTeman, storeTodo } from "../store";
export default 
    function People() {
        const people = storeTeman(state => state.people); 
        const todoList = storeTodo(state => state.todoList)

        const teman = () => {
            return(
                <ul>
                    {people.map(person => <li key={person}>{person}</li>)}
                </ul>
            )
        } 
        const todo = () => {
            return(
                <ul>
                    {todoList.map(todo => <li key={todo}>{todo}</li>)}
                </ul>
            )
        } 

        return (
            <div>
            <h2>Daftar teman</h2>
                {teman()}
            <h2>TodoList : </h2>
                {todo()}
            </div>
        )
    }