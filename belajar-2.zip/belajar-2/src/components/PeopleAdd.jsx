import { storeTeman, storeTodo } from "../store";
import { useRef } from "react";
export default 
    function PeopleAdd() {
        const inputRefTeman = useRef();
        const inputRefTodo = useRef();

        const teman = storeTeman(state => state.addPerson);
        const todo = storeTodo(state => state.addTodo)

        const addTeman = () => {
            teman(inputRefTeman.current.value)
            console.log(`${inputRefTeman.current.value} added succesfuly `);
        }

        const addTodo = () => {
            todo(inputRefTodo.current.value)
            console.log(`${inputRefTodo.current.value} added todo sukses`);
        }
        
        return(
            <>
        <label>
            Add teman baru
            <input type="text" ref={inputRefTeman} />
            <button onClick={addTeman}>Add teman </button> <br/>
        </label>
        
        <label>
            Add Todo baru
            <input type="text" ref={inputRefTodo} />
            <button onClick={addTodo}>Add teman </button>
        </label>

            </>
        )

    }